# TODO List

> ## From The Odin Project's [curriculum](https://www.theodinproject.com/courses/javascript/lessons/todo-list)

> - [Live Demo](https://igorashs.github.io/todo-list/) :shipit:

## Assignment

> Build the TODO List.

## License

This project is licensed under the MIT License
